package com.example.vehicleemergencyap;

import android.widget.Filter;

public interface ViewHolder {
    Filter getFilter();
}
